package com.itbbelval.expotec;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.webkit.WebSettings;

public class SaberMaisActivity extends AppCompatActivity {

    WebView myWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saber_mais);

        //TODO - Programar redirecionamento
        myWebView = (WebView) findViewById(R.id.webview);
        myWebView.loadUrl("https://fieb.edu.br/noticia/edicao-2019-da-expotec-acontece-nos-dias-30-e-31-de-agosto/");

        WebSettings webSettings = myWebView.getSettings();
        //Habilitando o JavaScript
        webSettings.setJavaScriptEnabled(true);

    }
}
